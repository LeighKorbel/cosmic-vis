./partiview ./configure/dmandgas_evolve_64.cf
