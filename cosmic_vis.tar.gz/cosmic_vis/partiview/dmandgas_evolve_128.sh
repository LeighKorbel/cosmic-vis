./partiview ./configure/dmandgas_evolve_128.cf
