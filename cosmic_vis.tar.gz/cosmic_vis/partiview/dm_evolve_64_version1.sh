./partiview ./configure/dm_evolve_64_version1.cf
