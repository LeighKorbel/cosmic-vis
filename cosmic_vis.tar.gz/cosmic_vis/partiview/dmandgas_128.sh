./partiview ./configure/dmandgas_128.cf
