./partiview ./configure/dmandgas_64.cf
